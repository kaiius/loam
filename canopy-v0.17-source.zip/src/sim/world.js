// The world: terrain, plants, food, critters, toys, eggs, creatures,
// and the day/night cycle. Owns the tick orchestration.

import { createRng } from './rng.js';
import { randomGenome, inherit, genomeDistance } from './genome.js';
import { randomPlantGenome, plantPhenotype, inheritPlant } from './plantgenome.js';
import { createCreature, updateCreature, creatureRadius } from './creature.js';
import { ageStage } from './biochem.js';
import { createCulture, sampleCulture, pruneExtinct, adoptTradition, fidelityOf } from './culture.js';
import { createBonds, tickBonds, detectTribes, nudgeBond } from './social.js';
import { createTeacher, tickTeacher, teacherDemo } from './teacher.js';
import { sizePitchFactor, hearThresh, baseLoud, pushUtterance, acousticDistance, lexiconDistance, wordName, LEX_CONTEXTS, pushContextWindow } from './language.js';

export const DAY_LENGTH = 300; // seconds per full day/night cycle

export function createWorld(seed = 1) {
  const rng = createRng(seed);
  const world = {
    rng,
    time: DAY_LENGTH * 0.32, // start mid-morning
    light: 1,
    width: 1600,
    height: 900,
    groundY: 800,
    // The canopy: the forest floor plus three tiers of branches. Branches
    // are platforms with a kind; overlapping branches in adjacent tiers are
    // linked by climbable gaps (computed below). Tanglekins are arboreal —
    // the vertical is the world, not a backdrop.
    platforms: [
      { x1: 0, x2: 1600, y: 800, kind: 'ground' }, // forest floor
      // lower branches
      { x1: 60, x2: 520, y: 650, kind: 'branch' },
      { x1: 480, x2: 980, y: 640, kind: 'branch' },
      { x1: 940, x2: 1540, y: 650, kind: 'branch' },
      // mid branches
      { x1: 200, x2: 700, y: 470, kind: 'branch' },
      { x1: 660, x2: 1180, y: 460, kind: 'branch' },
      { x1: 1120, x2: 1560, y: 470, kind: 'branch' },
      // upper branches
      { x1: 320, x2: 860, y: 290, kind: 'branch' },
      { x1: 820, x2: 1300, y: 280, kind: 'branch' },
    ],
    plants: [],
    foods: [],
    critters: [],
    toys: [],
    eggs: [],
    creatures: [],
    pebbles: [], // v0.9: pushable stones — the world as material
    events: [], // { type, creature?, t } — consumed by UI
    culture: createCulture(), // v0.7: the tradition registry — inheritance that isn't DNA
    lineage: new Map(), // v0.10: every creature ever born — { id: { id, name, parents, generation, bornAt, traits } }. Dead ancestors stay resolvable for the lineage view.
    bonds: createBonds(), // v0.12: pairwise social bonds — memory, not genetics
    tribes: [], // v0.12: detected bands (recomputed periodically, never assigned)
    exam: null, // v0.8: exam mode — { patches:[{x1,x2}], hot, hotInterval, coldInterval } | null
    onMeal: null, // v0.8: opt-in telemetry hooks for the exam harness (unset in play)
    onSpawn: null,
    // v0.9: dedicated RNG stream for material scatter (pebbles). Worldgen
    // order is load-bearing for determinism — cosmetic additions must never
    // shift the main stream's sequence (founder genomes, rolls, etc.).
    decorRng: createRng(seed * 31 + 7),
    // v0.13 "Roots":
    seenGenomes: new Set(), // genome hashes ever born — the beautiful-mutant watch
    novelParents: new Set(), // ids of living creatures with novel genomes
    divergenceLog: [], // { t, zones: { key: { trait: S } } } — Eliza's S per biome
    founderMeans: null, // { trait: mean } recorded at populate — the S baseline
    dupEvents: [], // v0.14: gene duplication/deletion events { t, kind, key, parents }
    speciesPrev: [], // v0.14: previous species-clustering snapshot for overlap matching
    speciesLog: [], // v0.14: species snapshots + split events for the evolution tracker
    speciesSeq: 0, // v0.14: running species id counter
    lineageKids: new Map(), // v0.14: parent id → [child ids] for the family tree
    // v0.14 "Voices": the acoustic commons. calls is the live registry
    // (decays over ~2s); zoneCalls is the per-zone dialect archive
    // ({ t, pitch, type }[], capped per zone) — the divergence tooling
    // reads it for dialect drift.
    calls: [],
    zoneCalls: {},
    // v0.14 "Voices": the Teacher — Sunny's in-sim avatar. A visitor, not
    // a tanglekin: no hunger, no mating, no death. teachLog records teaching
    // events as cultural inflection points for the evolution tracker.
    // The teacher draws from its OWN rng stream (v0.9 decorRng lesson):
    // a visitor must never shift the main stream's sequence.
    teacher: null,
    teacherRng: createRng(seed * 101 + 13),
    teachLog: [],
    // v0.14 "Voices": the waste cycle — digestion's byproduct returns to
    // the soil. soil[zone] = { waste, fertility }. Excretion feeds waste;
    // decomposition feeds fertility; fertility feeds plant growth. The loop
    // that turns a food chain into a cycle.
    soil: {
      verdant: { waste: 0, fertility: 0.5 },
      arid: { waste: 0, fertility: 0.5 },
      highland: { waste: 0, fertility: 0.5 },
    },
  };
  // Climb links: pairs of platforms whose x-ranges overlap and whose
  // vertical gap is climbable (60–240px). Computed once at worldgen —
  // the canopy's vertical roads.
  world.climbLinks = computeClimbLinks(world.platforms);
  world.teacher = createTeacher(world, 800, 0);
  return world;
}

// Two platforms are climb-linked if their spans overlap and the gap is
// within reach — close enough to scramble between, far enough to matter.
export function computeClimbLinks(platforms) {
  const links = [];
  for (let a = 0; a < platforms.length; a++) {
    for (let b = a + 1; b < platforms.length; b++) {
      const pa = platforms[a];
      const pb = platforms[b];
      const overlap = Math.min(pa.x2, pb.x2) - Math.max(pa.x1, pb.x1);
      const gap = Math.abs(pa.y - pb.y);
      if (overlap > 60 && gap >= 60 && gap <= 240) {
        links.push({ a, b, x1: Math.max(pa.x1, pb.x1), x2: Math.min(pa.x2, pb.x2) });
      }
    }
  }
  return links;
}

// Platform indices reachable by climbing from platform pi.
export function climbLinksFrom(world, pi) {
  const out = [];
  for (const l of world.climbLinks || []) {
    if (l.a === pi) out.push({ to: l.b, link: l });
    else if (l.b === pi) out.push({ to: l.a, link: l });
  }
  return out;
}

export function timeOfDay(world) {
  return (world.time / DAY_LENGTH) % 1;
}

// Smooth daylight: 1 at noon, ~0.12 at midnight.
export function updateLight(world) {
  const a = (timeOfDay(world) - 0.25) * Math.PI * 2;
  const s = Math.sin(a) * 0.5 + 0.5;
  world.light = 0.12 + 0.88 * s * s * (3 - 2 * s);
}

let nextObjId = 1;
function oid() {
  return nextObjId++;
}

// v0.11 biomes: the world is three ecological zones by x-slice. Different
// fruiting rates create different selection pressures — local adaptation.
export const ZONES = [
  { key: 'verdant', name: 'Verdant Valley', x1: 0, x2: 533, fruitMul: 0.6, tint: 'rgba(60,140,70,0.10)' },
  { key: 'arid', name: 'Arid Stretch', x1: 533, x2: 1066, fruitMul: 2.2, tint: 'rgba(190,150,80,0.12)' },
  { key: 'highland', name: 'Highland', x1: 1066, x2: 1601, fruitMul: 1.2, tint: 'rgba(120,140,170,0.10)' },
];

export function zoneAt(x) {
  for (const z of ZONES) if (x >= z.x1 && x < z.x2) return z;
  return ZONES[2];
}

export function addPlant(world, x, platformIndex, genome) {
  const plat = world.platforms[platformIndex];
  // v0.13: initial plant genomes come from the decor stream — worldgen order
  // is load-bearing for determinism, and plant genomes must never shift the
  // main stream's sequence (founder genomes, rolls, etc.).
  const g = genome || randomPlantGenome(world.decorRng || world.rng);
  world.plants.push({
    kind: 'plant', id: oid(), x, platformIndex, y: plat.y,
    growth: world.rng.range(0.3, 0.8), fruitTimer: world.rng.range(5, 25),
    sway: world.rng.range(0, Math.PI * 2),
    zone: zoneAt(x).key, // v0.11: biomes
    genome: g, pheno: plantPhenotype(g), // v0.13: plant genomes
  });
}

// v0.8: medicinal herbs. Same growth mechanics as fruit plants, but they bear
// bitter leaves (foodKind 'leaf') that purge illness instead of feeding hunger.
export function addHerb(world, x, platformIndex, genome) {
  const plat = world.platforms[platformIndex];
  const g = genome || randomPlantGenome(world.decorRng || world.rng);
  world.plants.push({
    kind: 'herb', id: oid(), x, platformIndex, y: plat.y,
    growth: world.rng.range(0.3, 0.8), fruitTimer: world.rng.range(5, 25),
    sway: world.rng.range(0, Math.PI * 2),
    zone: zoneAt(x).key, // v0.11: biomes
    genome: g, pheno: plantPhenotype(g), // v0.13: plant genomes
  });
}

export function addFood(world, x, platformIndex, kind = 'fruit', amount = 1, rotAfter = 0, opts = {}) {
  const plat = world.platforms[platformIndex];
  world.foods.push({
    kind: 'food', id: oid(), x, platformIndex, y: plat.y, foodKind: kind, amount,
    // v0.13: plant-genome provenance — which plant bore this fruit, its
    // bitterness, and its nutrition. Enables seed dispersal + learned
    // avoidance of bitter plants.
    plantId: opts.plantId || 0, bitterness: opts.bitterness || 0,
    nutrition: opts.nutrition || 1,
    // rotAfter: seconds until this fruit rots (0 = never). Nest-cache fruit
    // rots so it can't become a population-level food source — births must
    // increase food DEMAND, not supply, or the ecology explodes.
    rotsAt: rotAfter > 0 ? world.time + rotAfter : 0,
  });
  // v0.8 exam telemetry: opt-in spawn hook (intake-efficiency cost column).
  if (world.onSpawn) world.onSpawn(amount);
}

// v0.13 "Roots": seed dispersal — the coevolution loop. When a creature
// eats fruit, the parent plant's genes may ride along: a seed is deposited
// at the creature's position and sprouts into a seedling carrying a selfed
// child genome (crossover + mutation). High-yield plants get eaten more and
// spread; bitter plants are avoided and persist uneaten; arid selects for
// waterRet, highland for coldTol. Called from doEat.
export function disperseSeed(world, c, food) {
  if (!food.plantId) return;
  const parent = world.plants.find((p) => p.id === food.plantId);
  if (!parent || !parent.genome) return;
  const pYield = parent.pheno ? parent.pheno.yield : 0.5;
  if (!world.rng.chance(0.15 + 0.3 * pYield)) return;
  // Cap the flora: oldest seedlings are culled first.
  if (world.plants.length >= 60) {
    const seedlings = world.plants.filter((p) => p.growth < 1);
    if (seedlings.length > 0) {
      const oldest = seedlings[0];
      world.plants.splice(world.plants.indexOf(oldest), 1);
    } else return;
  }
  const plat = world.platforms[c.platformIndex];
  if (!plat) return;
  const x = Math.max(plat.x1 + 10, Math.min(plat.x2 - 10, c.x + world.rng.range(-40, 40)));
  const childGenome = inheritPlant(parent.genome, parent.genome, world.rng);
  if (parent.kind === 'herb') addHerb(world, x, c.platformIndex, childGenome);
  else addPlant(world, x, c.platformIndex, childGenome);
  const seedling = world.plants[world.plants.length - 1];
  seedling.growth = 0.05; // a true seedling — must mature before fruiting
  world.events.push({ type: 'seedDispersed', plant: seedling, parentId: parent.id, t: world.time });
}

export function addCritter(world, x, platformIndex, kind) {
  const plat = world.platforms[platformIndex];
  world.critters.push({
    kind, id: oid(), x, platformIndex, y: plat.y,
    vx: world.rng.pick([-1, 1]) * world.rng.range(15, 40),
    t: world.rng.range(0, 100),
  });
}

export function addToy(world, x, platformIndex) {
  const plat = world.platforms[platformIndex];
  world.toys.push({
    kind: 'ball', id: oid(), x, platformIndex, y: plat.y, vx: 0, r: 16,
  });
}

// v0.9 embodiment: pushable pebbles. The world is material — bodies act on
// it and it pushes back. Stones persist; creatures shove them by collision;
// heavy stones resist the pusher. Not decoration: they block, pile, and
// must be navigated.
export function addPebble(world, x, platformIndex) {
  const plat = world.platforms[platformIndex];
  world.pebbles.push({
    kind: 'pebble', id: oid(), x, platformIndex, y: plat.y,
    vx: 0, r: (world.decorRng || world.rng).range(9, 17),
  });
}

// v0.14: postzygotic barrier — hybrid viability falls as the parents'
// genome distance exceeds the threshold. Within-population matings
// (distance ~0.1) are untouched; genuinely divergent lineages produce
// weaker offspring. Exported for tests.
export const HYBRID_THRESHOLD = 0.30;
export function hybridViability(dist) {
  if (dist <= HYBRID_THRESHOLD) return 1;
  return Math.max(0.3, 1 - Math.min(0.7, (dist - HYBRID_THRESHOLD) * 2));
}
export function layEgg(world, x, platformIndex, genome, parents = null, gen = 0, traditionIds = [], gestMult = 1, parentDist = 0) {
  const plat = world.platforms[platformIndex];
  world.eggs.push({
    kind: 'egg', id: oid(), x, y: plat.y, platformIndex, genome, parents,
    gen, traditionIds, // v0.7: pedigree depth + vertical cultural inheritance
    timer: (18 + world.rng.range(0, 10)) * gestMult, wobble: 0, // v2 (L): gestation scales
    parentDist, // v0.14: parental genome distance — the hybrid penalty input
  });
}

export function tryMate(a, b) {
  // Called with world as `this` via world.tryMate — bound below.
  const world = this;
  const sa = ageStage(a.biochem, a.pheno);
  const sb = ageStage(b.biochem, b.pheno);
  if (sa !== 'adult' || sb !== 'adult') return false;
  if (a.sex === b.sex || a.mateCooldown > 0 || b.mateCooldown > 0) return false;
  // Breeding takes energy: malnourished creatures don't reproduce. This is
  // the density-dependent brake — when food is scarce, hunger rises and
  // births stop before the population overshoots into a crash.
  // (Founders are exempt: a new world needs its first generation established
  // before regulation kicks in.)
  const founderPair = !a.parents && !b.parents;
  if (!founderPair && (a.biochem.hunger > 0.7 || b.biochem.hunger > 0.7)) return false;
  // Carrying capacity: hard safety net. The hunger gate regulates day-to-day,
  // but stochastic bursts can still run away — this guarantees boundedness.
  // (A soft ramp suppressed births too aggressively at low populations and
  // caused extinctions; the hunger gate already handles gentle regulation.)
  const pop = world.creatures.reduce((n, c) => n + (c.alive ? 1 : 0), 0);
  if (pop >= 40) return false;
  // v2 (L): fertility peaks at a genetic age-fraction (window ±0.4 of
  // lifespan). Inside the window fertility is full; outside it declines.
  // Founder peak 0.5 covers the whole adult stage — neutral by default,
  // evolvable into early or late bloomers.
  const fertAt = (p) => {
    const t = p.biochem.age / (p.pheno.lifespanSec || 1);
    const d = Math.abs(t - (p.pheno.ferPeak ?? 0.5));
    return d <= 0.4 ? 1 : Math.max(0.2, 1 - (d - 0.4) * 2);
  };
  if (world.rng.next() > 0.35 + 0.4 * Math.min(a.pheno.fertility * fertAt(a), b.pheno.fertility * fertAt(b))) return false;
  const mom = a.sex === 'female' ? a : b;
  const dad = a.sex === 'female' ? b : a;
  // v0.5: clutches of two. One egg per mating kept the birth rate below the
  // death rate once drift and infant mortality took their cut; a pair of eggs
  // per mating gives lineages the demographic buffer to persist.
  // v2 (L): litter size is genetic (founder → 2, as before); gestation scales
  // the egg timer (founder → ×1.0, as before).
  const nEggs = mom.pheno.ferLitter ?? 2;
  const gestMult = 0.5 + (mom.pheno.ferGest ?? 0.5);
  // v0.7: pedigree depth for the ratchet metric, and vertical transmission —
  // hatchlings inherit their parents' traditions (the "N+1 contains N" half).
  const childGen = Math.max(a.generation || 0, b.generation || 0) + 1;
  const parentTraditions = [...new Set([...(mom.traditions || []), ...(dad.traditions || [])])];
  // v0.14: parental genome distance — the postzygotic barrier input.
  // v0.16 (delta d): lexicon distance joins the barrier — word-drift
  // becomes a reproductive barrier, which is what turns drift into
  // distinct languages. Additive, so language difference alone can push
  // a pairing over the hybrid threshold.
  const lexD = lexiconDistance(mom.lexicon, dad.lexicon);
  const parentDist = genomeDistance(mom.genome, dad.genome) + 0.35 * lexD;
  for (let i = 0; i < nEggs; i++) {
    const eg = inherit(mom.genome, dad.genome, world.rng);
    // v0.14: gene duplication/deletion events enter the world's record —
    // the evolution tracker marks them on the timeline.
    for (const e of eg.dupLog || []) {
      world.dupEvents.push({ t: world.time, kind: e.kind, key: e.key, parents: [mom.id, dad.id] });
    }
    if (world.dupEvents.length > 200) world.dupEvents.splice(0, world.dupEvents.length - 200);
    layEgg(world, (a.x + b.x) / 2 + world.rng.range(-30, 30), a.platformIndex, eg, [mom.id, dad.id], childGen, parentTraditions, gestMult, parentDist);
    mom.children.push('egg');
    dad.children.push('egg');
  }
  a.mateCooldown = 90;
  b.mateCooldown = 90;
  a.reward += 0.8;
  b.reward += 0.8;
  // v0.12: mating forms a pair bond — the strongest positive bond event.
  nudgeBond(world, a, b, 0.4);
  // v0.13: beautiful-mutant watch — a novel-genome parent that reproduces
  // proved its combination. Reproduction is the only fitness that counts.
  for (const p of [mom, dad]) {
    if (world.novelParents.has(p.id)) {
      world.novelParents.delete(p.id);
      world.events.push({ type: 'beautifulMutant', creature: p, mate: p === mom ? dad : mom, t: world.time });
    }
  }
  world.events.push({ type: 'mating', a, b, t: world.time });
  return true;
}

// v0.10 lineage: snapshot a newborn's heritable traits so the UI can show
// ancestry even after the parents die. Traits are the legible, evolvable
// phenotype values (0..1 floats, plus diet choice).
export const LINEAGE_TRAITS = ['size', 'legLength', 'spikes', 'fur', 'eyeSize', 'mouthSize', 'immunity', 'learningRate', 'boldness', 'lifespan'];

export function recordLineage(world, c) {
  const traits = {};
  for (const k of LINEAGE_TRAITS) traits[k] = c.pheno[k];
  traits.diet = c.pheno.diet;
  world.lineage.set(c.id, {
    id: c.id, name: c.name,
    parents: c.parents ? [...c.parents] : null,
    generation: c.generation || 0,
    bornAt: world.time,
    diedAt: null, // v0.14: closed by noteDeath
    cause: null,
    zone: zoneAt(c.x).key, // v0.11: birth biome
    speciesId: c.speciesId ?? null, // v0.14: species at birth (may split later)
    traits,
  });
  // v0.14: children index — the family tree walks down without scanning.
  if (c.parents) {
    for (const pid of c.parents) {
      if (typeof pid !== 'number') continue;
      let kids = world.lineageKids.get(pid);
      if (!kids) { kids = []; world.lineageKids.set(pid, kids); }
      if (kids.length < 60) kids.push(c.id);
    }
  }
  // Soft cap: forget the oldest records beyond 5000 (ancestor chains for
  // living creatures are walked at view time, so pruning the deep past is safe).
  if (world.lineage.size > 5000) {
    const first = world.lineage.keys().next().value;
    world.lineage.delete(first);
  }
}

// v0.14: death bookkeeping — the event for toasts, and the lineage record
// for the family tree (diedAt + cause close the creature's arc).
export function noteDeath(world, c, cause) {
  world.events.push({ type: 'death', creature: c, t: world.time, cause });
  const rec = world.lineage.get(c.id);
  if (rec) { rec.diedAt = world.time; rec.cause = cause; }
}
// Two creatures share a hash only if every allele matches to 3 decimals.
export function genomeHash(genome) {
  const parts = [];
  for (const key of Object.keys(genome.alleles).sort()) {
    const [a, b] = genome.alleles[key];
    parts.push(a.toFixed(3) + '/' + b.toFixed(3));
  }
  // v0.14: duplicated copies are part of identity.
  for (const key of Object.keys(genome.extra || {}).sort()) {
    const [a, b] = genome.extra[key];
    parts.push('x' + key + ':' + a.toFixed(3) + '/' + b.toFixed(3));
  }
  let h = 0;
  const s = parts.join('|');
  for (let i = 0; i < s.length; i++) {
    h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  }
  return h;
}

// v0.13: the beautiful-mutant watch. A birth whose genome hash was never
// seen before is flagged novel; if that individual later reproduces, the
// novel combination proved itself — a "beautiful mutant" (reproduction =
// fitness, the only fitness evolution recognizes).
export function checkNovelGenome(world, c) {
  const h = genomeHash(c.genome);
  if (world.seenGenomes.has(h)) return false;
  world.seenGenomes.add(h);
  // Soft cap: the deep past's genotypes are forgotten (10k cap).
  if (world.seenGenomes.size > 10000) {
    const first = world.seenGenomes.values().next().value;
    world.seenGenomes.delete(first);
  }
  world.novelParents.add(c.id);
  world.events.push({ type: 'novelGenome', creature: c, t: world.time });
  return true;
}

// v0.14 "Voices": emit a grounded call into the acoustic commons.
// Pitch = vocalPitch × (1 ± vocalRange × noise); earshot scales with
// vocalVolume. Calls live ~2 sim-seconds; the zone archive keeps the last
// 300 per zone for dialect measurement.
export function emitCall(world, c, type, proto = null) {
  const p = c.pheno;
  // The LEARNED pitch is what's heard: genetics sets the base voicePitch
  // at birth, imitation drifts it, and the accent is audible. This is what
  // makes dialects real — a zone's accent lives in ears, not just genes.
  // v0.16: body size sets base pitch (sizePitchFactor — big bodies rumble,
  // small bodies chirp; physics, not script). The optional proto carries
  // the lexicon's chosen prototype; without one the call is raw voice.
  const base = (c.voicePitch ?? p.vocalPitch ?? 0.5) * sizePitchFactor(p);
  const range = p.vocalRange ?? 0.3;
  const ap = proto || {};
  const pitch = ap.pitch !== undefined ? ap.pitch
    : Math.max(0.05, Math.min(1, base * (1 + (world.rng.next() * 2 - 1) * range)));
  const length = ap.length !== undefined ? ap.length : 0.15 + world.rng.next() * 0.5;
  const loudness = ap.loudness !== undefined ? ap.loudness : baseLoud(p);
  const volume = p.vocalVolume ?? 0.5;
  const earshot = 200 + volume * 400; // kept for compatibility
  const zkey = zoneAt(c.x).key;
  const cplat = world.platforms[c.platformIndex];
  const call = {
    t: world.time, type,
    pitch: Math.max(0.05, Math.min(1, pitch)),
    length: Math.max(0.05, Math.min(1.2, length)),
    loudness: Math.max(0.05, Math.min(1, loudness)),
    volume, earshot,
    platformIndex: c.platformIndex, x: c.x, y: cplat ? cplat.y : 0,
    zone: zkey, callerId: c.id, callerName: c.name, fromTeacher: false,
    proto: null,
  };
  call.proto = { pitch: call.pitch, length: call.length, loudness: call.loudness };
  world.calls.push(call);
  let log = world.zoneCalls[zkey];
  if (!log) { log = []; world.zoneCalls[zkey] = log; }
  log.push({ t: world.time, pitch: call.pitch, type });
  if (log.length > 300) log.splice(0, log.length - 300);
  pushUtterance(world, call); // v0.16: the Tongues notebook's raw material
  return call;
}

// v0.16: what does creature c hear right now? Sound as physics — the
// recent call with the strongest amplitude at c's ear: 1/d cylindrical
// spreading, platform-slab + foliage occlusion along the ray, then the
// hearing-threshold gene gates reception. What arrives (pitch, length,
// loudness-at-ear, direction) is slightly noisy. Returns { heard: 0..1,
// pitch, alarm } for the old senses, plus the acoustic event for the
// lexicon.
export const CALL_REF_D = 400; // loudness 0.5 carries ~400px unoccluded
export function callsHeardBy(world, c) {
  const plat = world.platforms[c.platformIndex];
  const hearY = plat ? plat.y : 0;
  const thr = hearThresh(c.pheno || {});
  let best = null, bestAmp = 0;
  const calls = world.calls || [];
  for (let i = 0; i < calls.length; i++) {
    const call = calls[i];
    if (!call || call.callerId === c.id) continue;
    const dx = call.x - c.x;
    const dy = (call.y !== undefined ? call.y : hearY) - hearY;
    const d = Math.sqrt(dx * dx + dy * dy);
    let amp = (call.loudness !== undefined ? call.loudness : 0.5) * CALL_REF_D / Math.max(d, 1);
    if (amp < thr) continue; // inaudible even unoccluded
    amp *= soundOcclusion(world, call.x, call.y !== undefined ? call.y : hearY, c.x, hearY);
    if (amp < thr) continue;
    const age = world.time - call.t;
    const score = amp * Math.max(0, 1 - age / 2);
    if (score > bestAmp) { bestAmp = score; best = call; best._ampAtEar = amp; }
  }
  if (!best) return { heard: 0, pitch: 0, alarm: false, call: null };
  const heard = Math.max(0, Math.min(1, (bestAmp - thr) / Math.max(0.05, 1.5 - thr)));
  const nz = world.rng.next() * 2 - 1;
  return {
    heard,
    pitch: Math.max(0.05, Math.min(1, best.pitch * (1 + nz * 0.03))),
    alarm: best.type === 'alarm',
    call: best,
    length: best.length,
    loudnessAtEar: best._ampAtEar,
    direction: Math.abs(best.x - c.x) < 1 ? 0 : Math.sign(best.x - c.x),
  };
}

// v0.16: occlusion along the ray (delta e) — branch slabs and foliage
// puffs eat sound. Endpoints' own slabs don't count (the ray travels
// along the caller's / hearer's own branch, it doesn't punch through).
function segmentHitsSlab(x1, y1, x2, y2, pl) {
  const near1 = Math.abs(y1 - pl.y) < 14 && x1 >= pl.x1 - 4 && x1 <= pl.x2 + 4;
  const near2 = Math.abs(y2 - pl.y) < 14 && x2 >= pl.x1 - 4 && x2 <= pl.x2 + 4;
  if (near1 || near2) return false;
  const dy = y2 - y1;
  if (Math.abs(dy) < 1e-6) return false;
  for (const edge of [pl.y - 10, pl.y + 10]) {
    const t = (edge - y1) / dy;
    if (t > 0.02 && t < 0.98) {
      const x = x1 + (x2 - x1) * t;
      if (x >= pl.x1 && x <= pl.x2) return true;
    }
  }
  return false;
}

export function foliageDensityAt(world, x, y) {
  let d = 0;
  const plats = world.platforms;
  const plants = world.plants || [];
  for (let i = 0; i < plants.length; i++) {
    const pl = plants[i];
    const plat = plats[pl.platformIndex];
    if (!plat) continue;
    const dx = x - pl.x, dy = y - (plat.y - 70); // foliage puff above the branch
    const d2 = dx * dx + dy * dy;
    if (d2 < 1210000) d += Math.exp(-d2 / 24200); // σ=110
  }
  return d;
}

export function soundOcclusion(world, x1, y1, x2, y2) {
  let att = 1;
  const plats = world.platforms || [];
  for (let i = 0; i < plats.length; i++) {
    if (segmentHitsSlab(x1, y1, x2, y2, plats[i])) att *= 0.55;
  }
  const N = 10;
  let fol = 0;
  for (let i = 1; i < N; i++) {
    const t = i / N;
    fol += foliageDensityAt(world, x1 + (x2 - x1) * t, y1 + (y2 - y1) * t);
  }
  fol /= (N - 1);
  att *= Math.max(0.25, 1 - 0.6 * Math.min(1, fol));
  return att;
}

// v0.16: troop-level word census (delta c — culture lives at the troop
// level). Greedy-clusters each tribe's lexicon entries by acoustic distance
// into shared words; tracks speaker counts and spread/die trends for the
// Tongues notebook. Writes entry.speakers back for the forget rule.
export function censusTroopWords(world) {
  const out = [];
  const tribes = world.tribes || [];
  const byId = new Map(world.creatures.map((c) => [c.id, c]));
  tribes.forEach((tribe, ti) => {
    const members = (tribe.members || [])
      .map((id) => byId.get(id))
      .filter((c) => c && c.alive && c.lexicon);
    if (!members.length) return;
    const clusters = [];
    for (const c of members) {
      for (const e of c.lexicon.entries) {
        if (e.confidence < 0.25) continue;
        let placed = null;
        for (const cl of clusters) {
          if (acousticDistance(cl.centroid, e.proto) < 0.18) { placed = cl; break; }
        }
        if (!placed) {
          placed = { members: [], centroid: { pitch: e.proto.pitch, length: e.proto.length, loudness: e.proto.loudness } };
          clusters.push(placed);
        }
        placed.members.push({ c, e });
      }
    }
    const words = clusters.map((cl) => {
      let sw = 0;
      const cent = { pitch: 0, length: 0, loudness: 0 };
      const contexts = { food: 0, alarm: 0, mate: 0, contact: 0, come: 0 };
      const speakers = new Set();
      let total = 0;
      for (const { c, e } of cl.members) {
        const w = 0.5 + e.confidence;
        sw += w;
        cent.pitch += e.proto.pitch * w;
        cent.length += e.proto.length * w;
        cent.loudness += e.proto.loudness * w;
        for (const k of LEX_CONTEXTS) contexts[k] += e.contexts[k] || 0;
        speakers.add(c.id);
        total += e.heard + e.used;
      }
      cent.pitch /= sw; cent.length /= sw; cent.loudness /= sw;
      for (const { e } of cl.members) e.speakers = speakers.size;
      return {
        name: wordName(cent), proto: cent,
        speakers: speakers.size, contexts, total, trend: '•',
      };
    });
    words.sort((a, b) => b.speakers - a.speakers || b.total - a.total);
    out.push({
      tribeIndex: ti, homeX: tribe.homeX,
      memberCount: members.length, words: words.slice(0, 12),
    });
  });
  // Spread-vs-die trend against the previous census.
  const prevMap = new Map();
  for (const t of world._prevTroopWords || []) {
    for (const w of t.words) prevMap.set(`${Math.round(t.homeX)}:${w.name}`, w.speakers);
  }
  for (const t of out) {
    for (const w of t.words) {
      const ps = prevMap.get(`${Math.round(t.homeX)}:${w.name}`);
      w.trend = ps === undefined ? '•' : w.speakers > ps ? '▲' : w.speakers < ps ? '▼' : '•';
    }
  }
  world._prevTroopWords = out;
  return out;
}

// ---- v0.14 "Voices": the waste cycle ----
// Digestion's byproduct, lawfully. A bite's mass splits: nutrition feeds
// blood sugar (doEat → _ate → tickBiochem), the rest becomes gut waste.
// Excretion is proportional clearance into the creature's current zone —
// no timers, no dice, and the gut can never go negative. Decomposition
// converts raw waste into fertility; fertility relaxes toward the 0.5
// baseline (leaching) so the soil is a dynamic equilibrium, not a battery.
// Fertility feeds plant growth: 0.5 → neutral ×1.0.
export const WASTE_FRACTION = 0.35; // of each bite's mass becomes gut waste
export const EXCRETE_RATE = 0.6; // per-second proportional gut clearance
// Soil dynamics (retuned v0.14-disgust): decomposition must OUTPACE fouling
// or odor pegs at 1.0 everywhere inhabited and the smell carries no
// information. SOIL_DECAY=0.1 → waste half-life ~7s; typical inhabited zones
// sit at waste 0.5–1.5 (odor 0.1–0.4, a gradient), only true crowding hits
// full stink. Fertility equilibrium: fert − 0.5 = 0.5 × waste — empty ground
// 0.5, typical ground 0.75–1.25, rich ground caps at 1.5.
export const SOIL_DECAY = 0.1; // per-second proportional waste→fertility
export const SOIL_CONV_EFF = 0.02; // fertility gained per unit waste decomposed
export const SOIL_LEACH = 0.004; // per-second relaxation of fertility to 0.5
export const SOIL_FERT_MAX = 1.5;
export const WASTE_ODOR_SCALE = 4; // soil-waste units that read as full stink
export const CONTAM_ILLNESS = 0.15; // illness per unit bite at full contamination
// v0.14.1 "Detritus": nothing leaves the loop. Rot, scraps, shed leaves all
// compost into the zone soil — death feeds the ground that feeds the plants.
export const SCRAP_FRACTION = 0.12; // of each bite falls as litter
export const SCRAP_ROT = 45; // seconds before a scrap composts
export const SCRAP_NUTRITION = 0.35; // scraps are poor food
export const LITTER_RATE = 0.004; // soil-waste per second per plant at growthRate 0.5

// v0.14: disgust's information channel — how fouled the ground smells here,
// 0 (clean) to 1 (full stink). Tolerates stub worlds without soil (see the
// jumpNear range-gate test). The sense the instinct reads.
export function wasteOdorOf(world, x) {
  const soil = world.soil;
  const s = soil && soil[zoneAt(x).key];
  return s ? Math.min(1, s.waste / WASTE_ODOR_SCALE) : 0;
}

export function excrete(c, world, dt) {
  if (!c.gut || c.gut <= 0 || !world.soil) return;
  const dep = Math.min(c.gut, c.gut * EXCRETE_RATE * dt);
  if (dep <= 0) return;
  c.gut -= dep;
  const s = world.soil[zoneAt(c.x).key];
  if (s) s.waste += dep;
}

export function tickSoil(world, dt) {
  if (!world.soil) return;
  for (const z of ZONES) {
    const s = world.soil[z.key];
    if (!s) continue;
    // Decomposition: raw waste becomes fertility.
    const conv = Math.min(s.waste, s.waste * SOIL_DECAY * dt);
    s.waste -= conv;
    s.fertility = Math.min(SOIL_FERT_MAX, s.fertility + conv * SOIL_CONV_EFF);
    // Leaching: unused fertility washes out toward the baseline.
    s.fertility += (0.5 - s.fertility) * Math.min(1, SOIL_LEACH * dt);
    // v0.14.1: the land remembers — first crossing into rich ground is
    // history, not just chemistry. Noted once per zone per enrichment.
    if (s.fertility >= 1.0 && !s.richNoted) {
      s.richNoted = true;
      if (world.events) world.events.push({ type: 'soilRich', zone: z.key, t: world.time });
    } else if (s.fertility < 0.8) {
      s.richNoted = false; // lean times reset the record; richness can return
    }
  }
}

// v0.14.1 "Detritus": rot is not deletion. When food expires uneaten, its
// remaining mass composts into the zone soil — corpse meat after the
// scavengers have had their 150s, nest fruit, fallen scraps, bitter leaves.
// What the eaters don't take, the ground does.
export function compostRot(world) {
  for (let i = world.foods.length - 1; i >= 0; i--) {
    const f = world.foods[i];
    if (f.rotsAt > 0 && world.time >= f.rotsAt) {
      const s = world.soil && world.soil[zoneAt(f.x).key];
      if (s) s.waste += f.amount * (f.nutrition || 1);
      world.foods.splice(i, 1);
    }
  }
}

// v0.14.1: leaf litter — the unused parts of plants. Every plant sheds mass
// into its zone's soil as it grows; fast growers shed more. Shed leaves are
// not an item (no render, no sense surface); they go straight to the ground.
export function shedLitter(world, dt) {
  if (!world.soil) return;
  for (const p of world.plants) {
    const s = world.soil[p.zone];
    if (!s) continue;
    const gr = (p.pheno && p.pheno.growthRate !== undefined) ? p.pheno.growthRate : 0.5;
    s.waste += LITTER_RATE * (0.5 + gr) * dt;
  }
}

// Plant growth multiplier from soil fertility. Exported for tests and UI.
export function soilGrowthMul(world, zoneKey) {
  const soil = world.soil || {};
  const s = soil[zoneKey];
  const f = s ? s.fertility : 0.5;
  return 0.7 + 0.6 * f;
}
// S = μ_zone(adults now) − μ_founders. Positive S = the biome selected
// upward on that trait; negative = downward. Computed every 6 sim-minutes.
// v0.13: divergence metric (Eliza's S). Per biome, per tracked trait:
// S = μ_zone(adults now) − μ_founders. Positive S = the biome selected
// upward on that trait; negative = downward. Computed every 6 sim-minutes.
// v0.17 "Bauplan": the body plan joins the divergence census — wings,
// grasp pairs, sails, gills, fins, and segment counts are the traits the
// bauplan release exists to watch diverge.
export const DIVERGENCE_CREATURE_TRAITS = ['instHomeSeek', 'size', 'bulk', 'curiosity', 'boldness', 'vocalPitch',
  'wingArea', 'graspPairs', 'sailArea', 'gillArea', 'finArea', 'bodySegs'];
export const DIVERGENCE_PLANT_TRAITS = ['waterRet', 'coldTol', 'bitterness', 'yield'];

export function recordFounderMeans(world) {
  const means = {};
  const n = world.creatures.length;
  if (n === 0) return;
  for (const k of DIVERGENCE_CREATURE_TRAITS) {
    let sum = 0;
    for (const c of world.creatures) sum += c.pheno[k] !== undefined ? c.pheno[k] : 0.5;
    means[k] = sum / n;
  }
  for (const k of DIVERGENCE_PLANT_TRAITS) {
    let sum = 0, m = 0;
    for (const p of world.plants) {
      if (p.pheno && p.pheno[k] !== undefined) { sum += p.pheno[k]; m++; }
    }
    means['plant_' + k] = m > 0 ? sum / m : 0.5;
  }
  world.founderMeans = means;
}

export function computeDivergence(world) {
  if (!world.founderMeans) return null;
  const snap = { t: world.time, zones: {} };
  for (const z of ZONES) {
    const zs = { key: z.key };
    // Creatures: adults currently in this zone.
    const adults = world.creatures.filter((c) => c.alive && zoneAt(c.x).key === z.key);
    for (const k of DIVERGENCE_CREATURE_TRAITS) {
      if (adults.length === 0) { zs[k] = 0; continue; }
      let sum = 0;
      for (const c of adults) sum += c.pheno[k] !== undefined ? c.pheno[k] : 0.5;
      zs[k] = sum / adults.length - world.founderMeans[k];
    }
    // Plants: all plants rooted in this zone.
    const plants = world.plants.filter((p) => p.zone === z.key && p.pheno);
    for (const k of DIVERGENCE_PLANT_TRAITS) {
      const pk = 'plant_' + k;
      if (plants.length === 0) { zs[pk] = 0; continue; }
      let sum = 0;
      for (const p of plants) sum += p.pheno[k] !== undefined ? p.pheno[k] : 0.5;
      zs[pk] = sum / plants.length - world.founderMeans[pk];
    }
    snap.zones[z.key] = zs;
  }
  world.divergenceLog.push(snap);
  // Keep the log bounded: one snapshot per 6 sim-minutes, cap at 500.
  if (world.divergenceLog.length > 500) world.divergenceLog.splice(0, world.divergenceLog.length - 500);
  return snap;
}

// ---- v0.14 "Voices": speciation ----
// Species are detected, never assigned — single-linkage clustering of
// adults by genome distance. Cluster ids persist across snapshots by member
// overlap; a cluster whose members split into two viable groups is a
// speciation event, logged for the evolution tracker and announced.
export const SPECIES_DIST = 0.25; // below this distance: same species
export function computeSpecies(world) {
  const adults = world.creatures.filter((c) => {
    if (!c.alive || !c.genome) return false;
    const st = ageStage(c.biochem, c.pheno);
    return st === 'adult' || st === 'senior';
  });
  const clusters = [];
  outer: for (const c of adults) {
    for (const cl of clusters) {
      // Single linkage: close to ANY member — sample 8 for speed.
      const n = Math.min(cl.length, 8);
      for (let i = 0; i < n; i++) {
        if (genomeDistance(c.genome, cl[i].genome) < SPECIES_DIST) { cl.push(c); continue outer; }
      }
    }
    clusters.push([c]);
  }
  // Match clusters to the previous snapshot by member overlap → stable ids.
  const prev = world.speciesPrev || [];
  const used = new Set();
  const idOf = new Map();
  for (let i = 0; i < clusters.length; i++) {
    const ids = clusters[i].map((c) => c.id);
    let best = -1, bestOv = 0;
    for (let j = 0; j < prev.length; j++) {
      if (used.has(j)) continue;
      let ov = 0;
      for (const id of ids) if (prev[j].ids.has(id)) ov++;
      if (ov > bestOv) { bestOv = ov; best = j; }
    }
    if (best >= 0 && bestOv >= 2) { used.add(best); idOf.set(i, prev[best].id); }
    else idOf.set(i, ++world.speciesSeq);
  }
  for (let i = 0; i < clusters.length; i++) {
    const id = idOf.get(i);
    for (const c of clusters[i]) c.speciesId = id;
  }
  // Speciation: a previous cluster (≥6 members) whose members now live in
  // ≥2 current clusters of ≥3 each has split.
  for (const p of prev) {
    if (p.ids.size < 6) continue;
    const dist = new Map(); // current species id → member count from p
    for (let i = 0; i < clusters.length; i++) {
      let n = 0;
      for (const c of clusters[i]) if (p.ids.has(c.id)) n++;
      if (n >= 3) dist.set(idOf.get(i), n);
    }
    if (dist.size >= 2) {
      const ev = { type: 'speciation', t: world.time, from: p.id, to: [...dist.keys()], sizes: [...dist.values()] };
      world.events.push(ev);
      world.speciesLog.push({ t: world.time, kind: 'split', ...ev });
    }
  }
  // The snapshot the evolution tracker draws: per-cluster size, mean voice
  // pitch (the dialect signature), and home zone.
  const snap = {
    t: world.time,
    kind: 'snapshot',
    clusters: clusters.map((cl, i) => {
      let pitch = 0;
      const zones = {};
      for (const c of cl) {
        pitch += c.voicePitch ?? 0.5;
        const zk = zoneAt(c.x).key;
        zones[zk] = (zones[zk] || 0) + 1;
      }
      const home = Object.keys(zones).sort((a, b) => zones[b] - zones[a])[0] || '?';
      return { id: idOf.get(i), size: cl.length, meanPitch: cl.length ? pitch / cl.length : 0.5, zone: home };
    }),
  };
  world.speciesLog.push(snap);
  if (world.speciesLog.length > 500) world.speciesLog.splice(0, world.speciesLog.length - 500);
  world.speciesPrev = clusters.map((cl, i) => ({ id: idOf.get(i), ids: new Set(cl.map((c) => c.id)) }));
  return snap;
}

function hatchEgg(world, egg) {  const c = createCreature(egg.genome, egg.x, egg.platformIndex, world.rng, {
    parents: egg.parents,
    generation: egg.gen || 0,
  });
  c.name = uniqueName(world, c.name);
  // v0.14: postzygotic barrier. A hatchling of divergent parents carries
  // the cost in its body — shorter life, less time to breed. The record
  // goes on the creature for the family tree.
  const hv = hybridViability(egg.parentDist || 0);
  if (hv < 1) {
    c.pheno.lifespanSec *= hv;
    c.hybrid = { dist: egg.parentDist, viability: hv };
  }
  // v0.7 vertical transmission: the hatchling inherits its parents'
  // traditions with fidelity-scaled loyalty — knowledge, not DNA.
  const fid = fidelityOf(c.pheno);
  for (const tid of egg.traditionIds || []) {
    const t = world.culture.traditions.find((x) => x.id === tid);
    if (t && world.rng.chance(fid * 0.85)) adoptTradition(world.culture, c, t, fid, world.rng);
  }
  // Newborns start hungry-ish and sleepy, like real babies. Set the
  // chemicals, not the readouts — the drives compute themselves.
  c.biochem.bloodSugar = 0.55;
  c.biochem.fatigue = 0.3;
  // Rooting reflex (v0.5): a newborn's first commitment is to eat. Combined
  // with the nest cache below, the first meal is near-guaranteed, and its
  // reward bootstraps the seekFood/eat learning loop.
  c.action = 'eat';
  c.actionTimer = 3;
  world.creatures.push(c);
  recordLineage(world, c);
  checkNovelGenome(world, c); // v0.13: beautiful-mutant watch
  world.events.push({ type: 'hatch', creature: c, t: world.time });
  // v0.5: nest cache. Hatchlings used to starve when the egg landed far from
  // food; now every nest is stocked with a first bite. That first meal's
  // reward bootstraps the seekFood/eat learning loop. One bite (not a full
  // fruit) + rots after 90s: it feeds the baby's first meal, not the
  // population — a full fruit per birth was a runaway feedback loop.
  addFood(world, egg.x + world.rng.range(-14, 14), egg.platformIndex, 'fruit', 0.35, 90);
  const i = world.eggs.indexOf(egg);
  if (i >= 0) world.eggs.splice(i, 1);
}

export function tickWorld(world, dt) {
  world.time += dt;
  updateLight(world);
  const rng = world.rng;

  // Plants grow fruit.
  for (const p of world.plants) {
    // v0.13: growth rate from the plant genome.
    // v0.14: the waste cycle closes the loop — soil fertility (fed by
    // excretion, built by decomposition) scales growth. Fertile ground
    // grows faster; exhausted ground stalls.
    p.growth = Math.min(1, p.growth + (dt / 150) * (0.5 + (p.pheno ? p.pheno.growthRate : 0.5)) * soilGrowthMul(world, p.zone));
    p.sway += dt;
    if (p.growth >= 1) {
      p.fruitTimer -= dt;
      if (p.fruitTimer <= 0) {
        // v0.8 exam mode: only the hot patch fruits at the exam rate; cold
        // patches fruit at the trickle rate (Infinity = barren). Null exam =
        // the normal ~19s world.
        let interval = 12 + rng.range(0, 14);
        const ex = world.exam;
        if (ex) {
          const hp = ex.patches[ex.hot];
          interval = (p.x >= hp.x1 && p.x <= hp.x2) ? ex.hotInterval : ex.coldInterval;
        } else {
          // v0.13 plant genomes: the fruiting interval, yield, and zone
          // stress all read the plant's own genome now.
          // v0.11 biomes + scarcity: zone sets the base rate; crowding slows
          // everything (density-dependent scarcity — more mouths, less fruit).
          // Herbs are counter-cyclical: medicine thrives where food is scarce.
          const ph = p.pheno || {};
          const intervalGene = 0.7 + 0.6 * (ph.interval !== undefined ? ph.interval : 0.5);
          let zoneStress;
          if (p.kind === 'herb') {
            zoneStress = p.zone === 'arid' ? 0.9 : 1.1;
          } else if (p.zone === 'arid') {
            // Drought: thirsty plants stall; water-retainers keep fruiting.
            zoneStress = zoneAt(p.x).fruitMul * (2 - (ph.waterRet !== undefined ? ph.waterRet : 0.5));
          } else if (p.zone === 'highland') {
            // Cold: the tender stall; the hardy keep fruiting.
            zoneStress = zoneAt(p.x).fruitMul * (1.6 - 0.6 * (ph.coldTol !== undefined ? ph.coldTol : 0.5));
          } else {
            zoneStress = zoneAt(p.x).fruitMul;
          }
          const densityMul = 1 + (world.creatures.length / 40) * 0.6;
          interval = interval * intervalGene * zoneStress * densityMul;
        }
        p.fruitTimer = interval;
        // Fruit hangs in the tree: it appears on the plant's own branch,
        // within reach of branch-dwellers. (The old world dropped it to
        // the ground; the canopy keeps its fruit where it grows.)
        // v0.8: herbs bear medicinal leaves instead of fruit.
        // v0.13: yield + fruitSize + bitterness from the plant genome; the
        // fruit remembers which plant bore it (seed dispersal).
        const dropKind = p.kind === 'herb' ? 'leaf' : 'fruit';
        const ph = p.pheno || {};
        const fruits = p.kind === 'herb' ? 1 : 1 + Math.round(2 * (ph.yield !== undefined ? ph.yield : 0.5));
        const nutrition = p.kind === 'herb'
          ? 0.3 * (0.5 + (ph.potency !== undefined ? ph.potency : 0.5))
          : 0.5 + (ph.fruitSize !== undefined ? ph.fruitSize : 0.5);
        for (let f = 0; f < fruits; f++) {
          addFood(world, p.x + rng.range(-30, 30), p.platformIndex, dropKind, 1, 0, {
            plantId: p.id, bitterness: ph.bitterness || 0, nutrition,
          });
        }
        if (world.foods.length > 60) world.foods.splice(0, world.foods.length - 60);
      }
    }
  }

  // v0.14: the waste cycle — decomposition and leaching run on the soil,
  // once per tick, after the plants have eaten from it.
  // v0.14.1: leaf litter sheds before decomposition runs, so shed mass
  // composts the same tick it falls.
  shedLitter(world, dt);
  tickSoil(world, dt);

  // v0.14.1: rot composts — see compostRot. (Only nest-cache fruit, scraps,
  // and carcass meat carry timers; plant fruit is eaten or it hangs.)
  compostRot(world);

  // Critters wander.
  for (const cr of world.critters) {
    const plat = world.platforms[cr.platformIndex];
    cr.t += dt;
    cr.x += cr.vx * dt;
    if (cr.x < plat.x1 + 10) { cr.x = plat.x1 + 10; cr.vx = Math.abs(cr.vx); }
    if (cr.x > plat.x2 - 10) { cr.x = plat.x2 - 10; cr.vx = -Math.abs(cr.vx); }
    if (rng.chance(dt * 0.2)) cr.vx = -cr.vx;
  }

  // Toys: friction.
  for (const t of world.toys) {
    const plat = world.platforms[t.platformIndex];
    t.x += t.vx * dt;
    t.vx *= 1 - Math.min(1, 2.5 * dt);
    if (Math.abs(t.vx) < 2) t.vx = 0;
    if (t.x < plat.x1 + t.r) { t.x = plat.x1 + t.r; t.vx = Math.abs(t.vx) * 0.5; }
    if (t.x > plat.x2 - t.r) { t.x = plat.x2 - t.r; t.vx = -Math.abs(t.vx) * 0.5; }
  }

  // v0.9: pebbles — friction, bounds, and one-way coupling with creatures.
  // Creatures shove pebbles (impulse + overlap separation, scaled by the
  // creature's size — babies kick weakly); pebbles NEVER push creatures
  // back. Two-way collision pinches a pebble between two approaching
  // creatures into a permanent 55px spacer, sterilizing the world — in a
  // 1D world there is no "around". Stones are kickable clutter, not walls.
  for (const p of world.pebbles) {
    const plat = world.platforms[p.platformIndex];
    p.x += p.vx * dt;
    p.vx *= 1 - Math.min(1, 3 * dt);
    if (Math.abs(p.vx) < 2) p.vx = 0;
    if (p.x < plat.x1 + p.r) { p.x = plat.x1 + p.r; p.vx = Math.abs(p.vx) * 0.4; }
    if (p.x > plat.x2 - p.r) { p.x = plat.x2 - p.r; p.vx = -Math.abs(p.vx) * 0.4; }
  }
  for (const c of world.creatures) {
    if (!c.alive) continue;
    const cr = creatureRadius(c);
    const kick = 90 * (cr / 16); // bigger bodies kick harder
    for (const p of world.pebbles) {
      if (p.platformIndex !== c.platformIndex) continue;
      const dx = p.x - c.x;
      const overlap = cr + p.r - Math.abs(dx);
      if (overlap > 0) {
        const dir = dx === 0 ? c.facing : Math.sign(dx);
        // Heavier stones (bigger r) take less velocity.
        const heaviness = p.r / 17;
        p.vx += dir * kick * dt / heaviness;
        p.x += dir * overlap;
      }
    }
  }

  // Eggs hatch.
  for (const egg of [...world.eggs]) {
    egg.timer -= dt;
    egg.wobble = Math.max(0, egg.wobble - dt);
    if (egg.timer < 3) egg.wobble = 0.3; // wobbling before hatch
    if (egg.timer <= 0) hatchEgg(world, egg);
  }

  // Creatures.
  rebuildSpatialIndex(world);
  // v0.14: calls older than 2 sim-seconds fade from the acoustic commons.
  if (world.calls.length) {
    const cutoff = world.time - 2;
    let w = 0;
    for (let i = 0; i < world.calls.length; i++) {
      if (world.calls[i].t >= cutoff) world.calls[w++] = world.calls[i];
    }
    world.calls.length = w;
  }
  for (const c of world.creatures) {
    updateCreature(c, world, dt);
  }
  // v0.14 "Voices": the Teacher — Sunny's visitor avatar. Ticks after the
  // creatures; its calls land in the 2s acoustic registry and are heard on
  // the next tick. A visitor, never interleaved with creature update order.
  if (world.teacher) tickTeacher(world, world.teacher, dt);
  // v0.12: bond dynamics run on the fresh positions — familiarity,
  // play-together, decay, and pruning of the dead.
  tickBonds(world, dt);
  // v0.12: tribe detection every 60 sim-seconds — bands are detected,
  // never assigned.
  if (Math.floor(world.time / 60) !== Math.floor((world.time - dt) / 60)) {
    world.tribes = detectTribes(world);
  }
  // v0.16 "Tongues": the troop lexicon census every 30 sim-seconds —
  // cluster each tribe's entries into shared words (culture lives at the
  // troop level, delta c). Also feeds the forget rule and the notebook.
  if (Math.floor(world.time / 30) !== Math.floor((world.time - dt) / 30)) {
    world.troopWords = censusTroopWords(world);
  }
  // v0.16: death is salient — witnesses within 400px on the same branch
  // get 'alarm' pushed into their context window (delta a, hearer half:
  // the most salient observable context, weighted by recency).
  for (const ev of world.events) {
    if (ev.type !== 'death' || !ev.creature) continue;
    if (world.time - ev.t > dt + 0.001) continue; // only this tick's deaths
    const dc = ev.creature;
    for (const c of world.creatures) {
      if (!c.alive || c === dc || c.platformIndex !== dc.platformIndex) continue;
      if (Math.abs(c.x - dc.x) < 400) pushContextWindow(c, 'alarm', 1.0, world.time);
    }
    // v0.16: the teacher names the danger — the Rosetta stone's DANGER.
    // A sharp high motif, exact pitch, where the students can hear it.
    const te = world.teacher;
    if (te && te.platformIndex === dc.platformIndex &&
        Math.abs(te.x - dc.x) < 500 &&
        !te.demoQueue.length && world.time - (te.lastDemoT || 0) > 20) {
      teacherDemo(world, te, [0.85, 0.92, 0.85], 'danger');
    }
  }
  // v0.13: divergence snapshot every 6 sim-minutes — Eliza's S per biome.
  // v0.14: species clustering rides the same snapshot.
  if (Math.floor(world.time / 360) !== Math.floor((world.time - dt) / 360)) {
    computeDivergence(world);
    computeSpecies(world);
  }
  // Remove the dead (UI reads events first).
  // v0.7: the dead leave carcasses — meat for the diet gene's new niche.
  // Scavenging, not predation: nobody hunts, but carnivores finally eat
  // at full value. Carcasses rot in 150s; they feed individuals, not the
  // population (the v0.5 nest-cache lesson, applied).
  const dead = [];
  for (let i = world.creatures.length - 1; i >= 0; i--) {
    if (!world.creatures[i].alive) dead.push(...world.creatures.splice(i, 1));
  }
  for (const d of dead) {
    addFood(world, d.x, d.platformIndex, 'meat', 1.2, 150);
  }
  // v0.7: traditions whose last carrier died go extinct here — the library
  // test, running continuously.
  const extinct = pruneExtinct(world.culture, world.creatures);
  for (const t of extinct) {
    world.events.push({ type: 'traditionLost', name: t.name, t: world.time });
  }
  // Ratchet census every 5 sim-minutes.
  if (Math.floor(world.time / 300) !== Math.floor((world.time - dt) / 300)) {
    sampleCulture(world);
  }

  if (world.events.length > 60) world.events.splice(0, world.events.length - 60);
}

// Per-tick spatial index: platformIndex -> creatures sorted by x.
// Turns the O(n^2) all-pairs neighbor sense scan into O(n log n).
// Positions are at most one tick stale (creatures move after sensing).
function rebuildSpatialIndex(world) {
  const idx = new Map();
  for (const c of world.creatures) {
    if (!c.alive) continue;
    let arr = idx.get(c.platformIndex);
    if (!arr) { arr = []; idx.set(c.platformIndex, arr); }
    arr.push(c);
  }
  for (const arr of idx.values()) arr.sort((a, b) => a.x - b.x);
  world._spatial = idx;
}

// Bind tryMate so creature code can call world.tryMate(a, b).
export function bindWorld(world) {
  world.tryMate = tryMate.bind(world);
  return world;
}

// Creature names must be unique within a world (the pool is small).
export function uniqueName(world, name) {
  const used = new Set(world.creatures.map((c) => c.name));
  if (!used.has(name)) return name;
  let i = 2;
  while (used.has(`${name} ${i}`)) i++;
  return `${name} ${i}`;
}

export function populate(world) {
  const rng = world.rng;
  // The canopy's ecology: fruit trees grow ON the branches (plants are
  // indexed by platform — a tree on branch 4 fruits on branch 4); medicinal
  // herbs are undergrowth on the forest floor.
  // v0.11 biomes: verdant valley is lush, the arid stretch is harsh (one
  // fruit tree, but extra medicinal herbs), the highland is moderate.
  addPlant(world, 200, 1); addPlant(world, 420, 1); // lower-left branch trees
  addPlant(world, 700, 2); // lower-mid
  addPlant(world, 1150, 3); addPlant(world, 1400, 3); // lower-right
  addPlant(world, 450, 4); addPlant(world, 900, 5); // mid branches
  addPlant(world, 1250, 6);
  addPlant(world, 600, 7); addPlant(world, 1050, 8); // upper branches
  // v0.8: medicinal herbs, on the forest floor where the sick descend.
  // v0.11: they thrive where food is scarcest.
  addHerb(world, 650, 0); addHerb(world, 950, 0); addHerb(world, 1300, 0);
  // Starter food: hang fruit in the branches so the first tanglekins don't
  // starve immediately.
  const branchIdx = [1, 2, 3, 4, 5, 6];
  for (let i = 0; i < 8; i++) {
    const pi = branchIdx[i % branchIdx.length];
    const plat = world.platforms[pi];
    addFood(world, rng.range(plat.x1 + 40, plat.x2 - 40), pi, 'fruit', 1);
  }
  // Critters in the branches, a ball on the forest floor.
  for (let i = 0; i < 5; i++) addCritter(world, rng.range(100, 1500), 1 + rng.int(0, 5), 'bug');
  for (let i = 0; i < 3; i++) addCritter(world, rng.range(200, 1400), 4 + rng.int(0, 2), 'butterfly');
  addToy(world, 800, 0);
  // v0.9: pebbles scattered on the forest floor — the world as material.
  for (let i = 0; i < 8; i++) addPebble(world, rng.range(80, 1520), 0);
  // Four founder tanglekins with fresh random genomes, born in the lower
  // branches. (v0.5: was two. Two founders made every lineage a coin flip —
  // four founders (two breeding pairs) give the population the demographic
  // buffer it needs to survive drift.)
  const founders = [];
  const names = ['Pip', 'Moss'];
  // Founders start on adjacent lower branches where the climb links are —
  // 180px spacing keeps adjacent founders inside the 240px breeding-backstop
  // range but outside the 150px contagion range.
  const starts = [[400, 1], [580, 1], [760, 2], [940, 2]];
  for (let i = 0; i < 4; i++) {
    const [fx, fpi] = starts[i];
    const c = createCreature(randomGenome(rng), fx, fpi, rng,
      i < 2 ? { name: names[i] } : {});
    c.name = uniqueName(world, c.name);
    // Start them as young adults, not juveniles. The breeding window is
    // 25%–80% of lifespan, and juvenile founders kept dying (starvation,
    // illness, short lifespans) before they could ever mate — the seed-11 /
    // seed-99 extinction pattern: "aren't breeding and keep dying out".
    // 0.4 clears even the slowest maturation (matTime stretches childhood
    // to 37.5% of lifespan), so every founder is breedable from the first
    // minute the player watches.
    c.biochem.age = c.pheno.lifespanSec * 0.4;
    recordLineage(world, c);
    founders.push(c);
  }
  // Guarantee two males and two females so every new world is breedable.
  // (Shuffled, so Pip and Moss aren't always the same sexes.)
  const sexes = ['male', 'male', 'female', 'female'];
  for (let i = sexes.length - 1; i > 0; i--) {
    const j = rng.int(0, i);
    [sexes[i], sexes[j]] = [sexes[j], sexes[i]];
  }
  founders.forEach((c, i) => { c.sex = sexes[i]; });
  world.creatures.push(...founders);
  // Every founder gets a fruit within sight of its start — the starter
  // fruit above is randomly placed and can land out of a newborn's range,
  // starving juveniles before they learn to forage.
  for (const c of founders) {
    const plat = world.platforms[c.platformIndex];
    const fx = Math.max(plat.x1 + 20, Math.min(plat.x2 - 20, c.x + rng.range(-60, 60)));
    addFood(world, fx, c.platformIndex, 'fruit', 1);
  }
  // v0.13: founders are the genomic baseline — register their hashes so the
  // beautiful-mutant watch only fires on genuinely new combinations. Record
  // founder trait means for the divergence metric (Eliza's S).
  for (const c of founders) world.seenGenomes.add(genomeHash(c.genome));
  recordFounderMeans(world);
  return world;
}
